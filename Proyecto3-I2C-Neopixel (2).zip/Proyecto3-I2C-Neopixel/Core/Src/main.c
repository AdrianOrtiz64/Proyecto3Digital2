/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

#include <stdio.h>
#include <string.h>
#include "ili9341.h"
#include "font.h"

#include "bitmaps.h"


/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
FATFS fs;
FATFS *pfs;
FIL fil;
FRESULT fres;
DWORD fre_clust;
uint32_t totalSpace, freeSpace;
char buffer[100];

#define COLOR_BLACK     0x0000
#define COLOR_WHITE     0xFFFF
#define COLOR_RED       0xF800
#define COLOR_GREEN     0x07E0
#define COLOR_BLUE      0x001F
#define COLOR_YELLOW    0xFFE0
#define COLOR_CYAN      0x07FF
#define COLOR_MAGENTA   0xF81F

typedef enum {
    STATE_TITLE_SCREEN,
    STATE_SENSOR_DATA,
    STATE_WAITING_DATA
} app_state_t;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */

extern const uint16_t pantallaInicio[];
extern const uint16_t pantallaSensor[];

uint8_t rx_data;
char uart_buffer[64];

uint8_t uart_index = 0;
uint8_t sd_available = 0;

volatile uint8_t button_pressed = 0;
volatile uint8_t save_requested = 0;

float temp = 0.0;
float hum = 0.0;
char display_buffer[64];

app_state_t current_state = STATE_TITLE_SCREEN;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART3_UART_Init(void);
/* USER CODE BEGIN PFP */

void show_titulo(void);
void tft_show_valores(float temp, float hum);
void show_espera_valores(void);
void parse_sensor_data(char *data);

uint8_t init_sd_card(void);
uint8_t save_sensor_data(float temp, float hum);
void show_save_status(uint8_t status);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_SPI1_Init();
  MX_FATFS_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */

  HAL_UART_Receive_IT(&huart3, &rx_data, 1);

  LCD_Init();
  HAL_Delay(100);

  uint8_t test_msg[] = "NUCLEO_LISTO\n";
  HAL_UART_Transmit(&huart2, test_msg, sizeof(test_msg)-1, 100);
  HAL_UART_Transmit(&huart3, test_msg, sizeof(test_msg)-1, 100);

  sd_available = init_sd_card();

  show_titulo();

  HAL_NVIC_SetPriority(EXTI4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  	  static uint32_t last_command_sent = 0;
  	  static uint8_t command_retry_count = 0;

  	  if (button_pressed) {
  	      button_pressed = 0;

  	      if (current_state == STATE_TITLE_SCREEN) {

  	          // Cambiar a pantalla de espera
  	          current_state = STATE_WAITING_DATA;
  	          show_espera_valores();

  	          uint8_t cmd[] = "R\n";
  	          HAL_UART_Transmit(&huart3, cmd, sizeof(cmd)-1, 100);
  	          last_command_sent = HAL_GetTick();
  	          command_retry_count = 0;

  	      }
  	      else if (current_state == STATE_SENSOR_DATA) {
  	          current_state = STATE_TITLE_SCREEN;
  	          show_titulo();
  	      }

  	      HAL_Delay(300); // Debounce
  	  }

  	  if (save_requested) {
  		  save_requested = 0;

  	      if (current_state == STATE_SENSOR_DATA && sd_available) {
  	          uint8_t save_status = save_sensor_data(temp, hum);
  	          show_save_status(save_status);
  	      }
  	  }

  	  if (current_state == STATE_WAITING_DATA &&
  	      (HAL_GetTick() - last_command_sent > 2000) &&
  	      command_retry_count < 3) {

  	      command_retry_count++;
  	      uint8_t cmd[] = "R\n";
  	      HAL_UART_Transmit(&huart3, cmd, sizeof(cmd)-1, 100);
  	      last_command_sent = HAL_GetTick();

  	      char retry_msg[50];
  	      sprintf(retry_msg, "Reintento %d: Comando R enviado\n", command_retry_count);
  	      HAL_UART_Transmit(&huart2, (uint8_t*)retry_msg, strlen(retry_msg), 100);
  	  }

  	  if (current_state == STATE_WAITING_DATA &&
  	      (HAL_GetTick() - last_command_sent > 6000) &&
  	      command_retry_count >= 3) {

  	      current_state = STATE_TITLE_SCREEN;
  	      show_titulo();
  	      HAL_UART_Transmit(&huart2, (uint8_t*)"Timeout: Volviendo a titulo\n", 28, 100);
  	  }

  	  HAL_Delay(50);

    }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_6, GPIO_PIN_SET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PC1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB6 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_MEDIUM;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PB4 PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void show_titulo(void)
{
	LCD_Bitmap(0, 0, 320, 240, pantallaInicio);
}

void tft_show_valores(float temp, float hum)
{
    char buffer[32];

    // Dibuja fondo completo del sensor
    LCD_Bitmap(0, 0, 320, 240, pantallaSensor);

    int y_center = 120;

    // ---- TEMPERATURA IZQUIERDA ----
    snprintf(buffer, sizeof(buffer), " %.1f C", temp);
    LCD_Print(buffer,
              20,             // izquierda
              y_center - 10,
              2,              // MISMO tamaño que "Esperando datos..."
              COLOR_WHITE,
              COLOR_BLACK);   // Fondo negro (alto contraste)

    // ---- HUMEDAD DERECHA ----
    snprintf(buffer, sizeof(buffer), " %.1f %%", hum);
    LCD_Print(buffer,
              170,            // derecha
              y_center - 10,
              2,              // MISMO tamaño legible
              COLOR_WHITE,
              COLOR_BLACK);   // Fondo negro detrás del texto
}


void show_espera_valores(void)
{
    LCD_Bitmap(0, 0, 320, 240, pantallaSensor);
    LCD_Print("Esperando datos...", 40, 200, 2, COLOR_WHITE, COLOR_BLACK);
}


void parse_sensor_data(char *data)
{
    // Formato: T:24.7,H:65.9
    if (sscanf(data, "T:%f,H:%f", &temp, &hum) == 2) {

        current_state = STATE_SENSOR_DATA;
        tft_show_valores(temp, hum);

        // Debug serial
        sprintf(buffer, "Datos: Temp=%.1fC Hum=%.1f%%\n", temp, hum);
        HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);

    } else {
        LCD_Clear(COLOR_BLACK);
        LCD_Print("ERROR DE DATOS", 70, 80, 2, COLOR_RED, COLOR_BLACK);
        LCD_Print("Formato incorrecto", 50, 110, 1, COLOR_WHITE, COLOR_BLACK);
    }
}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_4) { // PB4 - Cambiar pantalla
        button_pressed = 1;
    }
    else if (GPIO_Pin == GPIO_PIN_5) { // PB5 - Guardar en SD
        save_requested = 1;
    }
    else if (GPIO_Pin == B1_Pin) { // Botón azul
        button_pressed = 1;
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART3) {
        if (rx_data == '\n' || rx_data == '\r') {
            if (uart_index > 0) {
                uart_buffer[uart_index] = '\0';
                parse_sensor_data(uart_buffer);
                uart_index = 0;
                memset(uart_buffer, 0, sizeof(uart_buffer));
            }
        } else {
            if (uart_index < sizeof(uart_buffer) - 1) {
                uart_buffer[uart_index++] = rx_data;
            }
        }
        HAL_UART_Receive_IT(&huart3, &rx_data, 1);
    }
}

uint8_t init_sd_card(void)
{
    FRESULT fres;

    // CS high antes de iniciar
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
    HAL_Delay(10);

    // Montar SD
    fres = f_mount(&fs, "", 1);
    if (fres != FR_OK) {
        sprintf(buffer, "f_mount ERROR = %d\n", fres);
        HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);
        return 0;
    }

    // Prueba de archivo
    fres = f_open(&fil, "test.txt", FA_WRITE | FA_CREATE_ALWAYS);
    if (fres != FR_OK) {
        sprintf(buffer, "f_open ERROR = %d\n", fres);
        HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);
        return 0;
    }

    f_puts("SD OK\n", &fil);
    f_close(&fil);

    HAL_UART_Transmit(&huart2, (uint8_t*)"SD READY\n", 9, 100);

    return 1;
}

uint8_t save_sensor_data(float temp, float hum)
{
    FRESULT fres;
    UINT bytes_written;
    char data_buffer[100];
    uint32_t timestamp = HAL_GetTick();

    fres = f_open(&fil, "0:/datos_sensor.txt", FA_OPEN_APPEND | FA_WRITE);
    if (fres != FR_OK) {
        fres = f_open(&fil, "0:/datos_sensor.txt", FA_CREATE_NEW | FA_WRITE);
        if (fres != FR_OK) {
            return 0;
        }
    }

    sprintf(data_buffer, "T:%lu|%.1f|%.1f\n", timestamp, temp, hum);
    fres = f_write(&fil, data_buffer, strlen(data_buffer), &bytes_written);
    f_close(&fil);

    if (fres == FR_OK && bytes_written == strlen(data_buffer)) {
        sprintf(buffer, "SD: Guardado - %s", data_buffer);
        HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);
        return 1;
    }

    return 0;
}

void show_save_status(uint8_t status)
{
    if (status) {
        LCD_Print("GUARDADO EN SD", 50, 160, 1, COLOR_GREEN, COLOR_BLACK);
    } else {
        LCD_Print("ERROR SD", 70, 160, 1, COLOR_RED, COLOR_BLACK);
    }
    HAL_Delay(1500);
    tft_show_valores(temp, hum);
}

/* USER CODE BEGIN 4 */

void fondoStart(void){
    for (int fondoFrame = 0; fondoFrame < 2; fondoFrame++) {
        LCD_Bitmap(0,0,320,240,pantallaInicio);
    }
}

void displayLectura(float temp, float humedad, uint8_t guardo){
    LCD_Bitmap(0,0,320,240,pantallaSensor);

    if(guardo){
        char mensaje[] = "Datos guardados en SD";
        LCD_Print(mensaje, 30, 100, 3, 0xFFFF, 0x0000);
    }

    char bufferTemp[20];
    char bufferHum[20];

    sprintf(bufferTemp, "%.1f°", temp);
    sprintf(bufferHum, "%.1f%%", humedad);

    LCD_Print(bufferTemp, 72, 103, 2, 0x001F, 0xFFFF);  // Temp azul
    LCD_Print(bufferHum, 170, 103, 2, 0x07E0, 0xFFFF); // Hum verde

    if (temp > 25) {
        for (int anim = 0; anim < 4; anim++) {
            LCD_Sprite(205, 155, 42, 32, kirbyFuego, 2, anim, 0, 0);
            HAL_Delay(80);
        }
    }
}

void pantallaCarga(void){
    LCD_Clear(0x4088);  // 🔵 Fondo azul (el filtro que te falta)

    LCD_Print("cargando datos", 85, 160, 2, 0xFFFF, 0x4088);
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
